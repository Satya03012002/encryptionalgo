package com.patya.demosatya;

import java.awt.image.BufferedImage;
import java.io.*;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;
import javax.imageio.ImageIO;
public class RSA {
   
    public static long RSAencrypt() {
        try {
           
            String inputFile = "C:/Users/91992/Downloads/Crypto/targettext.txt";
            int[][] data = readArrayFromFile(inputFile);

         
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
            keyPairGenerator.initialize(512);
            KeyPair keyPair = keyPairGenerator.generateKeyPair();

      
            PublicKey publicKey = keyPair.getPublic();
            PrivateKey privateKey = keyPair.getPrivate();

            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);

         
            long startTime = System.nanoTime();
          
            int[][] encryptedData = new int[data.length][data[0].length];
            for (int i = 0; i < data.length; i++) {
                for (int j = 0; j < data[i].length; j++) {
                    byte[] encryptedBytes = cipher.doFinal(intToBytes(data[i][j]));
                    encryptedData[i][j] = bytesToInt(encryptedBytes);
                }
            }
            long endTime = System.nanoTime();
            long encryptionTime = endTime - startTime;
            System.out.println(encryptionTime);
        

            String encryptedFile = "C:/Users/91992/Downloads/Crypto/RSA.txt";
            saveArrayToFile(encryptedData, encryptedFile);

            System.out.println("Encrypted 2D array saved to " + encryptedFile);
            
    int[][] encryptedArray = loadArrayFromFile("C:/Users/91992/Downloads/Crypto/RSA.txt");
            
            System.out.println(encryptedArray);

            
            BufferedImage encryptedImage = createImageFromPixelArray(encryptedArray);

           
            saveImageToFile(encryptedImage, "C:/Users/91992/Downloads/Crypto/RSA.jpg");
            return encryptionTime;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

  
    private static int[][] readArrayFromFile(String filePath) throws Exception {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        int rowCount = 0;
        int columnCount = 0;

        while ((line = reader.readLine()) != null) {
            String[] values = line.trim().split("\\s+");
            columnCount = values.length;
            rowCount++;
        }

        int[][] array = new int[rowCount][columnCount];
        reader.close();

        reader = new BufferedReader(new FileReader(filePath));
        int row = 0;

        while ((line = reader.readLine()) != null) {
            String[] values = line.trim().split("\\s+");
            for (int col = 0; col < columnCount; col++) {
                array[row][col] = Integer.parseInt(values[col]);
            }
            row++;
        }

        reader.close();
        return array;
    }


    private static void saveArrayToFile(int[][] array, String filePath) throws Exception {
        FileWriter writer = new FileWriter(filePath);
        for (int[] row : array) {
            for (int element : row) {
                writer.write(element + " ");
            }
            writer.write("\n");
        }
        writer.close();
    }


    private static byte[] intToBytes(int value) {
        return new byte[]{
                (byte) (value >>> 24),
                (byte) (value >>> 16),
                (byte) (value >>> 8),
                (byte) value
        };
    }


    private static int bytesToInt(byte[] bytes) {
        return (bytes[0] << 24)
                | ((bytes[1] & 0xFF) << 16)
                | ((bytes[2] & 0xFF) << 8)
                | (bytes[3] & 0xFF);
    }
    
    private static int[][] loadArrayFromFile(String fileName) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(fileName));
        String line;
        int row = 0;
        int[][] pixelArray = null;

        while ((line = reader.readLine()) != null) {
            String[] values = line.trim().split(" ");
            if (pixelArray == null) {
                pixelArray = new int[values.length][values.length];
            }
            for (int col = 0; col < values.length; col++) {
                pixelArray[row][col] = Integer.parseInt(values[col]);
            }
            row++;
        }

        reader.close();
        return pixelArray;
    }

    private static BufferedImage createImageFromPixelArray(int[][] array) {
        int width = array[0].length;
        int height = array.length;

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int pixelValue = array[y][x];
                image.setRGB(x, y, pixelValue);
            }
        }

        return image;
    }

    private static void saveImageToFile(BufferedImage image, String fileName) throws IOException {
        File imageFile = new File(fileName);
        ImageIO.write(image, "png", imageFile);
    }

}
