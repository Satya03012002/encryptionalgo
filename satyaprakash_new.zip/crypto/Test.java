package com.patya.demosatya;

import java.io.IOException;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import javax.imageio.ImageIO;

public class Test {

	public static void main(String[] args) {
		
        String imagePath = "C:/Users/91992/Downloads/Crypto/target.jpg"; // file:///C:/Users/91992/Downloads/Crypto/target.jpg

        try {
            File imageFile = new File(imagePath);
            BufferedImage image = ImageIO.read(imageFile);

            int width = image.getWidth();
            int height = image.getHeight();

            int[][] pixels = new int[height][width];

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int rgb = image.getRGB(x, y);
                    int alpha = (rgb >> 24) & 0xFF;
                    int red = (rgb >> 16) & 0xFF;
                    int green = (rgb >> 8) & 0xFF;
                    int blue = rgb & 0xFF;

                    int pixelValue = (alpha << 24) | (red << 16) | (green << 8) | blue;
                    pixels[y][x] = pixelValue;
                }
            }
            
            FileWriter writer = new FileWriter("C:/Users/91992/Downloads/Crypto/targettext.txt");
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    writer.write(pixels[y][x] + " ");
                }
                writer.write("\n");
            }
            writer.close();

            System.out.println("Pixel values saved to targettext.txt");

                		
    		long DESencryptTime = DES.DESencrypt();
    		long AESencryptTime = AES.AESencrypt();
    		long DES3encryptTime = DES3.DES3encrypt();
    		long RSAencryptTime = RSA.RSAencrypt();
    		
    		System.out.println(DESencryptTime);
    		System.out.println(AESencryptTime);
    		System.out.println(DES3encryptTime);
    		System.out.println(RSAencryptTime);

            
        } catch (IOException e) {
            e.printStackTrace();
        }
		
	}

}

